package org.metagnostic.jniport.test.regression;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class InheritedInterfaceFields
implements InheritedFieldsInterface
{

	public static void
	main(String[] args)
	{
		new InheritedInterfaceFields().test();
	}

	public void
	test()
	{
		System.out.println("interfaceIntField = " + interfaceIntField);
	}
}
