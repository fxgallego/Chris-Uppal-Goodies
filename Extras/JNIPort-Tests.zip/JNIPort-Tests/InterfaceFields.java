package org.metagnostic.jniport.test.regression;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public interface InterfaceFields
{
	// NB: these differ only in their redundant qualifiers
	public int						publicIntField = 1;
	public final int				publicFinalIntField = 2;
	public static int				publicStaticIntField = 3;
	public static final int			publicStaticFinalIntField = 4;
	int								defaultIntField = 5;
	final int						defaultFinalIntField = 6;
	static int						defaultStaticIntField = 7;
	static final int				defaultStaticFinalIntField = 8;
}
