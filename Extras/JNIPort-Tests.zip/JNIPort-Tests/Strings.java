package org.metagnostic.jniport.test.regression;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class Strings
{
	public static String
	make(int from, int to)
	{
		StringBuffer buffer = new StringBuffer(to - from);
		for (int i = from; i < to; i++)
			buffer.append((char)i);

		return new String(buffer);
	}


	public static String
	make(char from, char to)
	{
		return make((int)from, (int)to);
	}
}
