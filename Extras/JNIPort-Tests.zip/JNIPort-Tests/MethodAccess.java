package org.metagnostic.jniport.test.regression;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class MethodAccess
{
	public int						publicIntMethod() { return 1; }
	protected int					protectedIntMethod() { return 2; }
	/*default*/ int					defaultIntMethod() { return 3; }
	private int						privateIntMethod() { return 4; }

	public final int				publicFinalIntMethod() { return 11; }
	protected final int				protectedFinalIntMethod() { return 12; }
	/*default*/ final int			defaultFinalIntMethod() { return 13; }
	private final int				privateFinalIntMethod() { return 14; }

	public static int				publicStaticIntMethod() { return 101; }
	protected static int			protectedStaticIntMethod() { return 102; }
	/*default*/ static int			defaultStaticIntMethod() { return 103; }
	private static int				privateStaticIntMethod() { return 104; }

	public static final int			publicStaticFinalIntMethod() { return 111; }
	protected static final int		protectedStaticFinalIntMethod() { return 112; }
	/*default*/ static final int	defaultStaticFinalIntMethod() { return 113; }
	private static final int		privateStaticFinalIntMethod() { return 114; }
}
