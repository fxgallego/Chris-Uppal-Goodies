package org.metagnostic.jniport.test.regression;

class Test {}
class TestArray {}

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2003 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class AmbiguousSelectors
{
	// these should force the long form
	public String
	longForm(java.sql.Array array)
	{
		return "java.sql.Array";
	}
	public String
	longForm(java.lang.reflect.Array array)
	{
		return "java.lang.reflect.Array";
	}

	// these should force return type too
	public int
	returnType(Test[] tests)
	{
		return 2;
	}
	public double
	returnType(TestArray tests)
	{
		return 3.14159;
	}

	// these are irredemptably ambiguous
	public void
	incurable(Test[] tests)
	{
	}
	public void
	incurable(TestArray tests)
	{
	}
}