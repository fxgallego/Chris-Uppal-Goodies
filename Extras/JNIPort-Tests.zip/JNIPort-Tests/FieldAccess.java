package org.metagnostic.jniport.test.regression;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class FieldAccess
{
	public int						publicIntField = 1;
	protected int					protectedIntField = 2;
	/*default*/ int					defaultIntField = 3;
	private int						privateIntField = 4;

	public final int				publicFinalIntField = 11;
	protected final int				protectedFinalIntField = 12;
	/*default*/ final int			defaultFinalIntField = 13;
	private final int				privateFinalIntField = 14;

	public static int				publicStaticIntField = 101;
	protected static int			protectedStaticIntField = 102;
	/*default*/ static int			defaultStaticIntField = 103;
	private static int				privateStaticIntField = 104;

	public static final int			publicStaticFinalIntField = 111;
	protected static final int		protectedStaticFinalIntField = 112;
	/*default*/ static final int	defaultStaticFinalIntField = 113;
	private static final int		privateStaticFinalIntField = 114;
}
