package org.metagnostic.jniport.test.regression;

import java.util.EventObject;

/**
 * TestEventObject.java
 *<p>
 * Copyright &copy; 2003 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class TestEventObject
extends EventObject
{
	private String m_text;

	public
	TestEventObject(Object source, String text)
	{
		super(source);
		m_text = text;
	}

	
	public String
	getText()
	{
		return m_text;
	}


	public String
	toString()
	{
		return super.toString() + " " + m_text;
	}
}
