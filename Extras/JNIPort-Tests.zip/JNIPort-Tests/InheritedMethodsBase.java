package org.metagnostic.jniport.test.regression;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public abstract class InheritedMethodsBase
{
	public int				intMethod() { return 2; }

	public abstract int		abstractIntMethod();

	public static int		staticIntMethod() { return 222; }

	public static boolean	staticBooleanMethod() { return true; }
}
