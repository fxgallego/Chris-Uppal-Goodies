package org.metagnostic.jniport.test.regression;

import java.util.EventObject;

/**
 * TestEventListener.java
 *<p>
 * Copyright &copy; 2003 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public interface TestEventListener
{
	void onTestEvent(TestEventObject event);
}
