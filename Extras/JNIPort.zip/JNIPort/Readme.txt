Source for the Java support routines for JNIPport.  Actually just the
stuff for handling callbacks, and the JRockit patch, the rest of JNIPort
needs no additional Java support.
